public interface CustomerRepository {
    String findCustomerById(String id);
}
