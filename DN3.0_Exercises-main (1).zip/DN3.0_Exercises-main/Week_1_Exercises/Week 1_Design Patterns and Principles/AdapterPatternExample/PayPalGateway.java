public class PayPalGateway {
    public void makePayment(double amount) {
        System.out.println("Processing PayPal Payment of Rs. " + amount);
    }
}
